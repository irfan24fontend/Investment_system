<!doctype html>
<html lang="bn">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo e($title ?? config('app.name', 'Bottle Invest')); ?></title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<script src="https://cdn.tailwindcss.com/3.4.17"></script>
<script>tailwind.config={theme:{extend:{fontFamily:{sans:['Inter','Hind Siliguri','system-ui','sans-serif']}}}}</script>
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.14.1/dist/cdn.min.js"></script>
<style>[x-cloak]{display:none!important}</style>
</head>
<body class="bg-slate-50 text-slate-800 antialiased min-h-screen flex flex-col">
<?php
  $u = auth()->user();
  $unread = $u ? \App\Models\UserNotice::where('user_id', $u->id)->whereNull('read_at')->count() : 0;
  if ($u && $u->role === 'investor') $links = [['dashboard','Dashboard'],['offers','Offers'],['investments','My Investments'],['wallet','Wallet']];
  elseif ($u) {
    $links = [['admin.dashboard','Admin']];
    if ($u->hasRole('super_admin')) { $links[] = ['admin.offers','Offers']; $links[] = ['admin.audit','Audit']; }
    if ($u->hasRole('super_admin','finance_manager')) { array_push($links, ['admin.investors','Investors'],['admin.deposits','Deposits'],['admin.withdrawals','Withdrawals'],['admin.settlements','Settlements'],['admin.reports','Reports']); }
    if ($u->hasRole('super_admin','order_manager')) $links[] = ['admin.orders','Orders'];
  } else $links = [];
?>
<header class="bg-white border-b sticky top-0 z-40" x-data="{open:false}">
  <div class="max-w-6xl mx-auto px-4 h-14 flex items-center gap-6">
    <a href="<?php echo e(route('home')); ?>" class="font-bold text-indigo-700 text-lg"><?php echo e(config('app.name','Bottle Invest')); ?></a>
    <nav class="hidden md:flex items-center gap-5 text-sm">
      <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$r,$l]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route($r)); ?>" class="<?php echo e(request()->routeIs($r) ? 'text-indigo-700 font-semibold' : 'text-slate-600 hover:text-slate-900'); ?>"><?php echo e($l); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </nav>
    <div class="ml-auto flex items-center gap-3 text-sm">
      <?php if(auth()->guard()->check()): ?>
        <?php if($u->role==='investor'): ?><a href="<?php echo e(route('notices')); ?>" class="relative text-slate-600" title="Notifications">🔔<?php if($unread): ?><span class="absolute -top-2 -right-3 bg-red-600 text-white text-[10px] rounded-full px-1.5"><?php echo e($unread); ?></span><?php endif; ?></a><?php endif; ?>
        <form method="POST" action="<?php echo e(route('logout')); ?>" class="hidden md:block"><?php echo csrf_field(); ?><button class="text-slate-500 hover:text-slate-800">Logout</button></form>
        <button @click="open=!open" class="md:hidden p-2 border rounded" aria-label="Menu">☰</button>
      <?php else: ?>
        <a href="<?php echo e(route('login')); ?>" class="text-slate-600">Login</a><a href="<?php echo e(route('register')); ?>" class="bg-indigo-600 text-white px-3 py-1.5 rounded-lg">Register</a>
      <?php endif; ?>
    </div>
  </div>
  <?php if(auth()->guard()->check()): ?>
  <div x-show="open" x-cloak class="md:hidden border-t bg-white px-4 py-2 space-y-1 text-sm">
    <?php $__currentLoopData = $links; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$r,$l]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href="<?php echo e(route($r)); ?>" class="block py-2 <?php echo e(request()->routeIs($r) ? 'text-indigo-700 font-semibold' : ''); ?>"><?php echo e($l); ?></a><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($u->role==='investor'): ?><a href="<?php echo e(route('notices')); ?>" class="block py-2">Notifications <?php if($unread): ?>(<?php echo e($unread); ?>)<?php endif; ?></a><?php endif; ?>
    <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="py-2 text-slate-500">Logout (<?php echo e($u->name); ?>)</button></form>
  </div>
  <?php endif; ?>
</header>
<main class="max-w-6xl w-full mx-auto px-4 py-6 flex-1">
  <?php if(session('ok')): ?><div class="mb-4 p-3 rounded-lg bg-green-50 border border-green-200 text-green-800 text-sm" role="status">✔ <?php echo e(session('ok')); ?></div><?php endif; ?>
  <?php if($errors->any()): ?><div class="mb-4 p-3 rounded-lg bg-red-50 border border-red-200 text-red-800 text-sm" role="alert"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><div><?php echo e($e); ?></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div><?php endif; ?>
  <?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="border-t bg-white text-xs text-slate-500 py-4 text-center px-4">
  এই প্ল্যাটফর্মের বিনিয়োগে লাভের নিশ্চয়তা নেই; প্রকৃত ফলাফল অনুযায়ী লাভ বা লোকসান হতে পারে।
</footer>
<script>
document.querySelectorAll('[data-deadline]').forEach(function(el){
  function tick(){var ms=new Date(el.dataset.deadline)-new Date();
    if(ms<=0){el.textContent='Closed';return;}
    var d=Math.floor(ms/864e5),h=Math.floor(ms%864e5/36e5),m=Math.floor(ms%36e5/6e4);
    el.textContent=(d?d+'d ':'')+h+'h '+m+'m left';}
  tick();setInterval(tick,30000);});
</script>
</body></html>
<?php /**PATH D:\bottle-invest\resources\views/layouts/app.blade.php ENDPATH**/ ?>