<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-3">Financial report</h1>
<div class="grid md:grid-cols-3 gap-4 text-sm">
 <div class="bg-white p-4 rounded shadow">Total deposited<div class="text-xl font-bold">৳<?php echo e(number_format($deposited,2)); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Investor wallets (liability)<div class="text-xl font-bold">৳<?php echo e(number_format($byType['wallet'] ?? 0,2)); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Reserved withdrawals<div class="text-xl font-bold">৳<?php echo e(number_format($byType['withdrawal_reserved'] ?? 0,2)); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Active investments (obligation)<div class="text-xl font-bold">৳<?php echo e(number_format($activeInvest,2)); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Realized net (projects)<div class="text-xl font-bold">৳<?php echo e(number_format($settled->net,2)); ?></div><div class="text-xs">Investor profit ৳<?php echo e(number_format($settled->p,2)); ?> · investor loss ৳<?php echo e(number_format($settled->l,2)); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Expired / cancelled offers<div class="text-xl font-bold"><?php echo e($expired); ?> / <?php echo e($cancelled); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Ledger reconciliation<div class="text-xl font-bold <?php echo e($reconcile==='0.00'?'text-green-700':'text-red-700'); ?>"><?php echo e($reconcile==='0.00'?'Balanced':'MISMATCH ৳'.$reconcile); ?></div></div>
</div>
<a class="inline-block mt-4 bg-slate-800 text-white px-3 py-2 rounded" href="<?php echo e(route('admin.reports.ledger')); ?>">Export ledger CSV</a>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/reports.blade.php ENDPATH**/ ?>