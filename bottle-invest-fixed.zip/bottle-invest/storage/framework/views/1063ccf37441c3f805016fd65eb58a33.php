<?php $__env->startSection('content'); ?>
<div class="grid md:grid-cols-4 gap-4">
 <div class="bg-white p-4 rounded shadow">Investors to verify<div class="text-2xl font-bold"><?php echo e($toVerify); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Pending deposits<div class="text-2xl font-bold"><?php echo e($pendingDeposits); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Pending withdrawals<div class="text-2xl font-bold"><?php echo e($pendingWithdrawals); ?></div></div>
 <div class="bg-white p-4 rounded shadow">Ledger imbalance<div class="text-2xl font-bold <?php echo e($reconcile==='0.00'?'text-green-700':'text-red-700'); ?>">৳<?php echo e($reconcile); ?></div></div>
</div>
<h2 class="font-semibold mt-6">Offers by status</h2>
<ul class="text-sm"><?php $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s=>$c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($s); ?>: <?php echo e($c); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>