<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-3">Investors</h1>
<div class="bg-white rounded shadow overflow-x-auto"><table class="w-full text-sm"><tr class="bg-slate-100 text-left"><th class="p-2">Name</th><th>Email</th><th>Phone</th><th>Verified</th><th>Verify + payout number</th></tr>
<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr class="border-t"><td class="p-2"><?php echo e($u->name); ?></td><td><?php echo e($u->email); ?></td><td><?php echo e($u->phone); ?></td><td><?php echo e($u->investor_verified_at ? 'Yes' : 'No'); ?></td>
<td><form method="POST" action="<?php echo e(route('admin.investors.verify',$u)); ?>" onsubmit="return confirm('Confirm identity checked?')" class="flex gap-1"><?php echo csrf_field(); ?><input name="payout_account" value="<?php echo e($u->payout_account ?? $u->phone); ?>" class="border rounded p-1"><button class="bg-green-600 text-white px-2 rounded">Verify</button></form></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></table></div><?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/investors.blade.php ENDPATH**/ ?>