<?php $__env->startSection('content'); ?>
<div class="mb-6"><h1 class="text-2xl font-bold">Welcome, <?php echo e(auth()->user()->name); ?></h1><p class="text-sm text-slate-500">Your wallet and investments at a glance.</p></div>

<?php if(! auth()->user()->investor_verified_at): ?>
<div class="mb-6 p-4 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-sm">
  <b>Verification pending.</b> You can deposit now. Investing and withdrawing unlock after our staff verify your identity.
</div>
<?php endif; ?>

<div class="grid grid-cols-2 lg:grid-cols-4 gap-3 mb-8">
  <div class="col-span-2 lg:col-span-1 bg-indigo-600 text-white rounded-xl p-4 shadow"><div class="text-xs opacity-80">Available balance</div><div class="text-2xl font-bold">৳<?php echo e(number_format($available,2)); ?></div>
    <a href="<?php echo e(route('wallet')); ?>" class="inline-block mt-2 text-xs bg-white/20 rounded px-2 py-1">Deposit / Withdraw</a></div>
  <?php $__currentLoopData = [['Invested (not settled)',number_format($invested,2),'৳'],['Reserved for withdrawal',number_format($reservedWd,2),'৳'],['Pending deposits',number_format($pendingDeposits,2),'৳']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$l,$v,$c]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="bg-white rounded-xl border p-4"><div class="text-xs text-slate-500"><?php echo e($l); ?></div><div class="text-xl font-bold"><?php echo e($c); ?><?php echo e($v); ?></div></div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  <div class="bg-white rounded-xl border p-4"><div class="text-xs text-slate-500">Active investments</div><div class="text-xl font-bold"><?php echo e($active); ?></div></div>
  <div class="bg-white rounded-xl border p-4"><div class="text-xs text-slate-500">Completed</div><div class="text-xl font-bold"><?php echo e($completed); ?></div></div>
  <?php $net = (float)$realized->p - (float)$realized->l; ?>
  <div class="bg-white rounded-xl border p-4"><div class="text-xs text-slate-500">Realized profit / loss</div><div class="text-xl font-bold <?php echo e($net < 0 ? 'text-red-700' : 'text-green-700'); ?>"><?php echo e($net < 0 ? '−' : '+'); ?>৳<?php echo e(number_format(abs($net),2)); ?></div></div>
</div>

<div class="flex items-center justify-between mb-3"><h2 class="font-semibold text-lg">Open offers</h2><a href="<?php echo e(route('offers')); ?>" class="text-sm text-indigo-700">See all →</a></div>
<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
  <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <?php echo $__env->make('partials.offer-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="sm:col-span-3 bg-white border border-dashed rounded-xl p-8 text-center text-slate-500">No open offers right now. New offers will appear here and you will be notified.</div>
  <?php endif; ?>
</div>

<div class="flex items-center justify-between mb-3"><h2 class="font-semibold text-lg">Recent investments</h2><a href="<?php echo e(route('investments')); ?>" class="text-sm text-indigo-700">See all →</a></div>
<div class="bg-white border rounded-xl divide-y">
  <?php $__empty_1 = true; $__currentLoopData = $recent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <a href="<?php echo e(route('investments.show',$i)); ?>" class="flex items-center justify-between p-3 hover:bg-slate-50">
    <div><div class="font-medium"><?php echo e($i->offer->title); ?></div><div class="text-xs text-slate-500">INV-<?php echo e(str_pad($i->id,6,'0',STR_PAD_LEFT)); ?> · <?php echo e($i->confirmed_at?->timezone('Asia/Dhaka')->format('d M Y')); ?></div></div>
    <div class="text-right"><div class="font-semibold">৳<?php echo e(number_format($i->amount,2)); ?></div><?php echo $__env->make('partials.badge',['s'=>$i->status,'kind'=>'investment'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div>
  </a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <div class="p-6 text-center text-slate-500 text-sm">You have not invested yet.</div> <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/investor/dashboard.blade.php ENDPATH**/ ?>