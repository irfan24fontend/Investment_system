<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-3">Investment offers</h1>
<?php echo $__env->make('partials.offer-form', ['action' => route('admin.offers.store'), 'button' => 'Save draft', 'offer' => null], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="bg-white rounded shadow overflow-x-auto"><table class="w-full text-sm"><tr class="bg-slate-100 text-left"><th class="p-2">Code</th><th>Title</th><th>Required</th><th>Deadline</th><th>Status</th><th>Actions</th></tr>
<?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $btns = match($o->status) { 'draft' => ['published'=>'Publish','cancelled'=>'Cancel'], 'published' => ['paused'=>'Pause','cancelled'=>'Cancel'], 'paused' => ['published'=>'Publish','cancelled'=>'Cancel'], default => [] }; ?>
<tr class="border-t"><td class="p-2"><?php echo e($o->code); ?></td><td><?php echo e($o->title); ?></td><td>৳<?php echo e(number_format($o->required_amount,2)); ?></td><td><?php echo e($o->deadline_at->timezone('Asia/Dhaka')->format('d M Y H:i')); ?></td><td><?php echo e($o->status); ?></td>
<td class="flex flex-wrap gap-1 py-1">
<?php if(in_array($o->status,['draft','paused'])): ?><a href="<?php echo e(route('admin.offers.edit',$o)); ?>" class="px-2 border rounded text-indigo-700">Edit</a><?php endif; ?>
<?php if(in_array($o->status,['funded','completed'])): ?><a href="<?php echo e(route('admin.offers.progress',$o)); ?>" class="px-2 border rounded text-green-700">Progress / Complete</a><?php endif; ?>
<?php $__currentLoopData = $btns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $to=>$lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><form method="POST" action="<?php echo e(route('admin.offers.status',$o)); ?>" onsubmit="return confirm('<?php echo e($lbl); ?> this offer?')"><?php echo csrf_field(); ?><input type="hidden" name="to" value="<?php echo e($to); ?>"><button class="px-2 border rounded <?php echo e($to==='cancelled'?'text-red-700':''); ?>"><?php echo e($lbl); ?></button></form><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php if($o->status==='published'): ?><span class="text-xs text-slate-500 self-center">To edit: Pause first</span><?php endif; ?>
</td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></table></div><?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/offers.blade.php ENDPATH**/ ?>