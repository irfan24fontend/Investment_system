<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">Available offers</h1>
<form class="flex flex-wrap gap-2 mb-5"><input name="q" value="<?php echo e(request('q')); ?>" placeholder="Search offers…" class="border rounded-lg px-3 py-2 text-sm flex-1 min-w-[12rem]">
<select name="category" class="border rounded-lg px-3 py-2 text-sm"><option value="">All categories</option><?php $__currentLoopData = ['order_financing','stock_financing','bulk_purchase_financing']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($c); ?>" <?php if(request('category')===$c): echo 'selected'; endif; ?>><?php echo e(ucwords(str_replace('_',' ',$c))); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select>
<button class="px-4 bg-slate-800 text-white rounded-lg text-sm">Filter</button></form>
<div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
<?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $o): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?> <?php echo $__env->make('partials.offer-card', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="sm:col-span-3 bg-white border border-dashed rounded-xl p-10 text-center text-slate-500">No open offers match. Each offer can be funded by one investor only, so funded offers disappear.</div>
<?php endif; ?></div>
<div class="mt-4"><?php echo e($offers->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/investor/offers.blade.php ENDPATH**/ ?>