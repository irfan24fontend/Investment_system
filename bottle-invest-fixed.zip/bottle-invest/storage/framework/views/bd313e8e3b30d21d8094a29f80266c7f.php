<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-3">Audit log</h1>
<div class="bg-white rounded shadow overflow-x-auto"><table class="w-full text-xs"><?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr class="border-t"><td class="p-2"><?php echo e($r->created_at); ?></td><td>user <?php echo e($r->user_id); ?></td><td><?php echo e($r->action); ?></td><td><?php echo e($r->subject_type); ?> <?php echo e($r->subject_id); ?></td><td><?php echo e($r->meta); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></table></div><?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/audit.blade.php ENDPATH**/ ?>