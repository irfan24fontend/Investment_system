<?php $__env->startSection('content'); ?>
<h1 class="text-xl font-bold mb-3">Notifications</h1>
<?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?><div class="bg-white p-3 rounded shadow mb-2"><b><?php echo e($n->title); ?></b><div class="text-sm"><?php echo e($n->body); ?></div><div class="text-xs text-slate-400"><?php echo e($n->created_at->timezone('Asia/Dhaka')->format('d M Y H:i')); ?></div></div><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><p class="text-slate-500">Nothing yet.</p><?php endif; ?>
<?php echo e($rows->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/investor/notices.blade.php ENDPATH**/ ?>