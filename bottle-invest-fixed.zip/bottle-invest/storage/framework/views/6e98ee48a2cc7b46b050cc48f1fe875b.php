<?php
  $o = $offer ?? null;
  $fields = [
    ['code','Offer ID','text',$o?->code],['title','Title','text',$o?->title],['product_name','Product','text',$o?->product_name],
    ['quantity','Quantity','number',$o?->quantity],['unit_price','Unit price','number',$o?->unit_price],['other_expenses','Transport/other','number',$o?->other_expenses],
    ['business_contribution','Business contribution (0 = investor funds all)','number',$o?->business_contribution],
    ['investor_profit_share_pct','Investor share of net profit %','number',$o?->settlement_rules['investor_profit_share_pct'] ?? null],
    ['deadline_at','Deadline','datetime-local',$o?->deadline_at?->format('Y-m-d\TH:i')],
    ['estimated_settlement_date','Est. settlement','date',$o?->estimated_settlement_date ? \Illuminate\Support\Carbon::parse($o->estimated_settlement_date)->format('Y-m-d') : null],
  ];
?>
<form method="POST" action="<?php echo e($action); ?>" class="bg-white p-4 rounded shadow grid md:grid-cols-3 gap-2 mb-6"><?php echo csrf_field(); ?>
<?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as [$n,$l,$t,$def]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<label class="text-xs"><?php echo e($l); ?><input name="<?php echo e($n); ?>" type="<?php echo e($t); ?>" <?php if($t==='number'): ?> step="0.01" <?php endif; ?> value="<?php echo e(old($n, $def)); ?>" class="w-full border rounded p-2 text-sm"></label>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<label class="text-xs">Category<select name="category" class="w-full border rounded p-2 text-sm">
<?php $__currentLoopData = ['order_financing'=>'Order financing','stock_financing'=>'Stock financing','bulk_purchase_financing'=>'Bulk purchase']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v=>$lbl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($v); ?>" <?php if(old('category',$o?->category)===$v): echo 'selected'; endif; ?>><?php echo e($lbl); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></label>
<label class="text-xs md:col-span-3">Description<textarea name="description" rows="3" class="w-full border rounded p-2 text-sm"><?php echo e(old('description', $o?->description ?? \App\Models\InvestmentOffer::DEFAULT_DESCRIPTION)); ?></textarea></label>
<label class="text-xs md:col-span-3">Risk disclosure<textarea name="risk_disclosure" rows="3" required class="w-full border rounded p-2 text-sm"><?php echo e(old('risk_disclosure', $o?->risk_disclosure ?? \App\Models\InvestmentOffer::DEFAULT_RISK)); ?></textarea></label>
<p class="text-xs text-slate-500 md:col-span-3">Total cost and required amount are computed by the server.</p>
<button class="bg-indigo-600 text-white py-2 rounded"><?php echo e($button ?? 'Save'); ?></button>
</form>
<?php /**PATH D:\bottle-invest\resources\views/partials/offer-form.blade.php ENDPATH**/ ?>