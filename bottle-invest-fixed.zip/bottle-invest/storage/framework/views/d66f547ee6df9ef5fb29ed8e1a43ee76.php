<?php
  $snap = $i->agreement_snapshot; $no = 'INV-'.str_pad($i->id,6,'0',STR_PAD_LEFT);
  $dt = fn($v,$f='d M Y, h:i A') => $v ? \Illuminate\Support\Carbon::parse($v)->timezone('Asia/Dhaka')->format($f) : 'To be announced';
  $pct = $snap['rules']['investor_profit_share_pct'] ?? 0;
?>
<!doctype html>
<html lang="bn"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Agreement slip <?php echo e($no); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
  *{box-sizing:border-box} body{font-family:'Hind Siliguri','Noto Sans Bengali',Arial,sans-serif;background:#f1f5f9;margin:0;color:#0f172a}
  .page{max-width:780px;margin:16px auto;background:#fff;padding:32px;border:1px solid #e2e8f0}
  h1{font-size:22px;margin:0} h2{font-size:15px;margin:22px 0 8px;border-bottom:1px solid #e2e8f0;padding-bottom:4px}
  .top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;border-bottom:2px solid #4338ca;padding-bottom:12px}
  table{width:100%;border-collapse:collapse;font-size:14px} td{padding:6px 4px;vertical-align:top;border-bottom:1px dashed #e2e8f0} td:first-child{color:#64748b;width:38%}
  .amount{font-size:26px;font-weight:700} .box{background:#fffbeb;border:1px solid #fde68a;padding:10px;font-size:13px;white-space:pre-line}
  ol{font-size:13px;padding-left:18px;margin:0} li{margin:4px 0} .muted{color:#64748b;font-size:12px}
  .bar{max-width:780px;margin:12px auto;display:flex;gap:8px;justify-content:flex-end}
  .bar button,.bar a{padding:8px 14px;border-radius:8px;border:1px solid #cbd5e1;background:#fff;font:inherit;cursor:pointer;text-decoration:none;color:#0f172a}
  .bar .p{background:#4338ca;color:#fff;border-color:#4338ca}
  .stamp{display:inline-block;border:2px solid #16a34a;color:#16a34a;padding:2px 10px;border-radius:6px;font-weight:700;transform:rotate(-4deg)}
  @media print{body{background:#fff}.page{border:0;margin:0;padding:0}.bar{display:none}}
</style></head><body>
<div class="bar"><a href="<?php echo e(route('investments.show',$i)); ?>">← Back</a><a href="<?php echo e(route('investments.receipt',[$i,'download'=>1])); ?>">Download file</a><button class="p" onclick="window.print()">Print / Save as PDF</button></div>
<div class="page">
  <div class="top">
    <div><h1><?php echo e(config('app.name','Bottle Invest')); ?></h1><div class="muted">Investment Agreement &amp; Payment Receipt<br>বিনিয়োগ চুক্তি ও পেমেন্ট রসিদ</div></div>
    <div style="text-align:right"><div class="stamp">CONFIRMED</div><div class="muted" style="margin-top:6px">Slip no: <b><?php echo e($no); ?></b></div></div>
  </div>

  <h2>Investor / বিনিয়োগকারী</h2>
  <table><tr><td>Name</td><td><?php echo e($i->user->name); ?></td></tr><tr><td>Email</td><td><?php echo e($i->user->email); ?></td></tr><tr><td>Mobile</td><td><?php echo e($i->user->phone); ?></td></tr></table>

  <h2>Investment / বিনিয়োগ</h2>
  <table>
    <tr><td>Offer</td><td><?php echo e($snap['offer_code'] ?? $i->offer->code); ?>: <?php echo e($snap['title'] ?? $i->offer->title); ?></td></tr>
    <tr><td>Product</td><td><?php echo e($snap['product'] ?? $i->offer->product_name); ?> × <?php echo e(number_format($snap['quantity'] ?? $i->offer->quantity)); ?></td></tr>
    <tr><td>Total project cost</td><td>৳<?php echo e(number_format($snap['total_cost'] ?? $i->offer->total_cost,2)); ?></td></tr>
    <tr><td>Amount invested</td><td class="amount">৳<?php echo e(number_format($i->amount,2)); ?></td></tr>
    <tr><td>Payment method</td><td>Platform wallet balance</td></tr>
    <tr><td>Date &amp; time</td><td><?php echo e($dt($snap['accepted_at'])); ?> (Asia/Dhaka)</td></tr>
    <tr><td>Transaction ref</td><td style="word-break:break-all"><?php echo e($tx->uuid ?? 'N/A'); ?></td></tr>
    <tr><td>Est. settlement</td><td><?php echo e($dt($snap['estimated_settlement_date'] ?? $i->offer->estimated_settlement_date,'d M Y')); ?></td></tr>
    <tr><td>Status</td><td><?php echo e($i->status==='confirmed' ? 'Active' : ucfirst(str_replace('_',' ',$i->status))); ?></td></tr>
  </table>

  <h2>Terms accepted / গৃহীত শর্ত</h2>
  <ol>
    <li>Return model: the investor receives <b><?php echo e($pct); ?>%</b> of the <b>actual net profit</b> of this project. No profit or return is guaranteed. / প্রকল্পের প্রকৃত নিট লাভের <?php echo e($pct); ?>% বিনিয়োগকারী পাবেন; লাভের কোনো নিশ্চয়তা নেই।</li>
    <li>If the project makes a loss, the investor bears the loss in proportion to the amount funded, up to the invested amount. / লোকসান হলে বিনিয়োগকৃত অর্থের অনুপাতে, সর্বোচ্চ বিনিয়োগের পরিমাণ পর্যন্ত, লোকসান বহন করতে হবে।</li>
    <li>Net result = actual revenue received − refunds − actual project costs. Revenue is not treated as profit. / নিট ফলাফল = প্রকৃত প্রাপ্ত আয় − ফেরত − প্রকৃত খরচ।</li>
    <li>Settlement happens only after delivery, customer payment and costs are verified and approved by the company. It is not released automatically after a number of days. / ডেলিভারি, পেমেন্ট ও খরচ যাচাই ও অনুমোদনের পরেই সেটেলমেন্ট হবে; নির্দিষ্ট দিন পার হলেই স্বয়ংক্রিয়ভাবে নয়।</li>
    <li>The invested amount is held for this project until settlement and cannot be withdrawn before then. / সেটেলমেন্টের আগে বিনিয়োগের অর্থ তোলা যাবে না।</li>
  </ol>

  <h2>Risk disclosure / ঝুঁকি সম্পর্কিত তথ্য</h2>
  <div class="box"><?php echo e($snap['risk']); ?></div>

  <?php if($i->settlement && $i->settlement->status==='posted'): ?>
  <h2>Settlement / সেটেলমেন্ট</h2>
  <table><tr><td>Net result</td><td>৳<?php echo e(number_format($i->settlement->net_result,2)); ?></td></tr><tr><td>Profit / Loss</td><td>৳<?php echo e(number_format($i->settlement->investor_profit,2)); ?> / ৳<?php echo e(number_format($i->settlement->investor_loss,2)); ?></td></tr><tr><td>Credited to wallet</td><td><b>৳<?php echo e(number_format($i->settlement->payout,2)); ?></b></td></tr></table>
  <?php endif; ?>

  <p class="muted" style="margin-top:22px">This is a system-generated slip and needs no signature. It records the terms the investor accepted online at the time shown above. Generated <?php echo e(now()->timezone('Asia/Dhaka')->format('d M Y, h:i A')); ?>.<br>এটি সিস্টেম-জেনারেটেড স্লিপ, স্বাক্ষরের প্রয়োজন নেই।</p>
</div>
</body></html>
<?php /**PATH D:\bottle-invest\resources\views/investor/receipt.blade.php ENDPATH**/ ?>