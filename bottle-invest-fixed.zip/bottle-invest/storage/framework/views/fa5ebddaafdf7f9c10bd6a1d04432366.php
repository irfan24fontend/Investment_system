<?php $__env->startSection('content'); ?>
<form method="POST" action="<?php echo e(route('login')); ?>" class="max-w-sm mx-auto bg-white p-6 rounded shadow space-y-3"><?php echo csrf_field(); ?>
  <h1 class="text-xl font-bold">Login</h1>
  <label class="block text-sm">Email<input name="email" type="email" value="<?php echo e(old('email')); ?>" required class="w-full border rounded p-2"></label>
  <label class="block text-sm">Password<input name="password" type="password" required class="w-full border rounded p-2"></label>
  <label class="text-sm"><input type="checkbox" name="remember"> Remember me</label>
  <button class="w-full bg-indigo-600 text-white py-2 rounded">Login</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/auth/login.blade.php ENDPATH**/ ?>