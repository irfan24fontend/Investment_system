<?php $__env->startSection('content'); ?>
<h1 class="text-2xl font-bold mb-4">My investments</h1>
<div class="space-y-3">
<?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<div class="bg-white border rounded-xl p-4 flex flex-wrap items-center gap-3 justify-between">
  <div><div class="font-semibold"><?php echo e($i->offer->title); ?></div>
    <div class="text-xs text-slate-500">INV-<?php echo e(str_pad($i->id,6,'0',STR_PAD_LEFT)); ?> · <?php echo e($i->confirmed_at?->timezone('Asia/Dhaka')->format('d M Y, h:i A')); ?></div></div>
  <div class="text-right"><div class="font-bold">৳<?php echo e(number_format($i->amount,2)); ?></div><?php echo $__env->make('partials.badge',['s'=>$i->status,'kind'=>'investment'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php if($i->settlement && $i->settlement->status==='posted'): ?><div class="text-xs mt-1 <?php echo e($i->settlement->investor_loss>0 ? 'text-red-700' : 'text-green-700'); ?>"><?php echo e($i->settlement->investor_loss>0 ? 'Loss −৳'.number_format($i->settlement->investor_loss,2) : 'Profit +৳'.number_format($i->settlement->investor_profit,2)); ?> · Paid ৳<?php echo e(number_format($i->settlement->payout,2)); ?></div><?php endif; ?></div>
  <div class="flex gap-2 w-full sm:w-auto">
    <a href="<?php echo e(route('investments.show',$i)); ?>" class="px-3 py-1.5 border rounded-lg text-sm">Details</a>
    <a href="<?php echo e(route('investments.receipt',$i)); ?>" target="_blank" class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg text-sm">Agreement slip</a>
  </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?> <div class="bg-white border border-dashed rounded-xl p-10 text-center text-slate-500">No investments yet. <a class="text-indigo-700 underline" href="<?php echo e(route('offers')); ?>">Browse offers</a></div>
<?php endif; ?></div>
<div class="mt-4"><?php echo e($rows->links()); ?></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/investor/investments.blade.php ENDPATH**/ ?>