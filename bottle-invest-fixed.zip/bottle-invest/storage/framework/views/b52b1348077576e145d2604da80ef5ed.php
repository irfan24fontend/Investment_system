<a href="<?php echo e(route('offers.show', $o)); ?>" class="group bg-white rounded-xl border shadow-sm hover:shadow-md transition p-4 flex flex-col gap-2">
  <div class="flex items-center justify-between text-xs">
    <span class="px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700"><?php echo e(ucwords(str_replace('_',' ', $o->category))); ?></span>
    <span class="text-slate-400">#<?php echo e($o->code); ?></span>
  </div>
  <h3 class="font-semibold text-slate-900 group-hover:text-indigo-700"><?php echo e($o->title); ?></h3>
  <div class="text-sm text-slate-600"><?php echo e($o->product_name); ?> × <?php echo e(number_format($o->quantity)); ?></div>
  <div class="mt-1">
    <div class="text-xs text-slate-500">Required investment</div>
    <div class="text-2xl font-bold text-slate-900">৳<?php echo e(number_format($o->required_amount, 2)); ?></div>
  </div>
  <div class="grid grid-cols-2 gap-2 text-xs text-slate-500 border-t pt-2 mt-1">
    <div>Closes in<div class="font-semibold text-amber-700" data-deadline="<?php echo e($o->deadline_at->toIso8601String()); ?>">…</div></div>
    <div>Est. settlement<div class="font-semibold text-slate-700"><?php echo e($o->estimated_settlement_date ? $o->estimated_settlement_date->format('d M Y') : 'TBD'); ?></div></div>
  </div>
  <div class="text-[11px] text-slate-400">Return depends on actual result. Loss is possible.</div>
  <span class="mt-1 text-center bg-indigo-600 group-hover:bg-indigo-700 text-white rounded-lg py-2 text-sm font-medium">View details</span>
</a>
<?php /**PATH D:\bottle-invest\resources\views/partials/offer-card.blade.php ENDPATH**/ ?>