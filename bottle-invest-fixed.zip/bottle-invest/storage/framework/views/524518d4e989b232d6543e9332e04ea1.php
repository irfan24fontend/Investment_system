<?php $__env->startSection('content'); ?>
<a href="<?php echo e(route('admin.offers')); ?>" class="text-sm text-indigo-700">&larr; Back to offers</a>
<h1 class="text-xl font-bold my-3">Edit offer <?php echo e($offer->code); ?> <span class="text-sm font-normal text-slate-500">(<?php echo e($offer->status); ?>)</span></h1>
<?php echo $__env->make('partials.offer-form', ['action' => route('admin.offers.update', $offer), 'button' => 'Save changes', 'offer' => $offer], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\bottle-invest\resources\views/admin/offer-edit.blade.php ENDPATH**/ ?>