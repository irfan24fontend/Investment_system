@php
  $o = $offer ?? null;
  $fields = [
    ['code','Offer ID','text',$o?->code],['title','Title','text',$o?->title],['product_name','Product','text',$o?->product_name],
    ['quantity','Quantity','number',$o?->quantity],['unit_price','Unit price','number',$o?->unit_price],['other_expenses','Transport/other','number',$o?->other_expenses],
    ['business_contribution','Business contribution (0 = investor funds all)','number',$o?->business_contribution],
    ['investor_profit_share_pct','Investor share of net profit %','number',$o?->settlement_rules['investor_profit_share_pct'] ?? null],
    ['deadline_at','Deadline','datetime-local',$o?->deadline_at?->format('Y-m-d\TH:i')],
    ['estimated_settlement_date','Est. settlement','date',$o?->estimated_settlement_date ? \Illuminate\Support\Carbon::parse($o->estimated_settlement_date)->format('Y-m-d') : null],
  ];
@endphp
<form method="POST" action="{{ $action }}" class="bg-white p-4 rounded shadow grid md:grid-cols-3 gap-2 mb-6">@csrf
@foreach($fields as [$n,$l,$t,$def])
<label class="text-xs">{{ $l }}<input name="{{ $n }}" type="{{ $t }}" @if($t==='number') step="0.01" @endif value="{{ old($n, $def) }}" class="w-full border rounded p-2 text-sm"></label>
@endforeach
<label class="text-xs">Category<select name="category" class="w-full border rounded p-2 text-sm">
@foreach(['order_financing'=>'Order financing','stock_financing'=>'Stock financing','bulk_purchase_financing'=>'Bulk purchase'] as $v=>$lbl)<option value="{{ $v }}" @selected(old('category',$o?->category)===$v)>{{ $lbl }}</option>@endforeach</select></label>
<label class="text-xs md:col-span-3">Description<textarea name="description" rows="3" class="w-full border rounded p-2 text-sm">{{ old('description',$o?->description) }}</textarea></label>
<label class="text-xs md:col-span-3">Risk disclosure<textarea name="risk_disclosure" rows="3" required class="w-full border rounded p-2 text-sm">{{ old('risk_disclosure',$o?->risk_disclosure) }}</textarea></label>
<p class="text-xs text-slate-500 md:col-span-3">Total cost and required amount are computed by the server.</p>
<button class="bg-indigo-600 text-white py-2 rounded">{{ $button ?? 'Save' }}</button>
</form>
